import React, { useEffect, useState } from "react";

export default function DateTimeCard() {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const weekday = now.toLocaleDateString("en-US", { weekday: "long" });
  const dateLabel = now.toLocaleDateString("en-US", { day: "numeric", month: "long" });
  const time = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false });
  const seconds = now.toLocaleTimeString("en-US", { second: "2-digit" }).padStart(2, "0");

  return (
    <div
      className="relative shrink-0 rounded-[2rem] px-7 py-6 w-fit overflow-hidden"
      style={{
        background: "radial-gradient(120% 140% at 100% 0%, #2a2833 0%, #19181d 55%)",
      }}
    >
      {/* subtle accent glow */}
      <div
        className="pointer-events-none absolute -top-10 -right-10 w-32 h-32 rounded-full opacity-30 blur-2xl"
        style={{ background: "#F2A6CB" }}
      />

      <div className="relative flex items-center gap-1.5 mb-3">
        <span className="w-1.5 h-1.5 rounded-full bg-[#F2A6CB] animate-pulse" />
        <p className="text-[11px] font-semibold tracking-widest text-white/45 uppercase">Live</p>
      </div>

      <p className="relative text-lg font-heading font-bold text-white leading-tight">{weekday}</p>
      <p className="relative text-xs text-white/45 mt-0.5">{dateLabel}</p>

      <p className="relative text-5xl font-heading font-extrabold tabular-nums text-white mt-4 leading-none tracking-tight">
        {time}
        <span className="text-lg text-[#F2A6CB] font-bold align-top ml-1">:{seconds}</span>
      </p>
    </div>
  );
}
