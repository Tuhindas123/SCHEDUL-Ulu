import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Paperclip, X, CheckCircle2 } from "lucide-react";

import AppShell from "@/components/layout/AppShell";
import { FEEDBACK_ENDPOINT } from "@/lib/feedbackConfig";

const RATING_LABELS = {
  1: "Very confusing",
  2: "Confusing",
  3: "Okay",
  4: "Intuitive",
  5: "Extremely intuitive",
};

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function Feedback() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [osBrowser, setOsBrowser] = useState("");
  const [rating, setRating] = useState(null);
  const [bugs, setBugs] = useState("");
  const [missingFeature, setMissingFeature] = useState("");
  const [general, setGeneral] = useState("");
  const [screenshot, setScreenshot] = useState(null);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  const handleFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      setError("Screenshot must be under 5MB.");
      return;
    }
    setError("");
    setScreenshot(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!osBrowser.trim()) {
      setError("Please tell us your OS and browser.");
      return;
    }
    if (!rating) {
      setError("Please rate how intuitive the UI/UX felt.");
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        name: name.trim() || "Anonymous",
        email: email.trim(),
        osBrowser: osBrowser.trim(),
        rating,
        bugs: bugs.trim(),
        missingFeature: missingFeature.trim(),
        general: general.trim(),
      };

      if (screenshot) {
        payload.screenshotBase64 = await fileToBase64(screenshot);
        payload.screenshotName = screenshot.name;
        payload.screenshotType = screenshot.type;
      }

      if (FEEDBACK_ENDPOINT) {
        // Apps Script Web Apps don't return CORS headers, so the response
        // itself can't be read from the browser — "no-cors" lets the
        // request go through and the data still gets saved server-side.
        await fetch(FEEDBACK_ENDPOINT, {
          method: "POST",
          mode: "no-cors",
          headers: { "Content-Type": "text/plain;charset=utf-8" },
          body: JSON.stringify(payload),
        });
      } else {
        console.warn("FEEDBACK_ENDPOINT is not set — submission was not sent anywhere.");
      }

      setDone(true);
    } catch (err) {
      console.error("Failed to submit feedback:", err);
      setError("Something went wrong sending your feedback. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <AppShell>
        <div className="max-w-lg mx-auto">
          <div className="rounded-3xl bg-card border border-border/60 shadow-sm p-8 text-center">
            <div className="w-14 h-14 rounded-2xl bg-pastelMint text-pastelMint-foreground grid place-items-center mx-auto mb-4">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h1 className="text-xl font-heading font-bold text-foreground mb-1">Thanks for the feedback!</h1>
            <p className="text-sm text-muted-foreground mb-6">
              It really helps us get Flow Tracker ready for launch.
            </p>
            <Link
              to="/settings"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-primary text-primary-foreground font-medium text-sm"
            >
              Back to Settings
            </Link>
          </div>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="max-w-lg mx-auto">
        <Link to="/settings" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground mb-4 hover:text-foreground transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Settings
        </Link>

        <h1 className="text-2xl font-heading font-bold text-foreground">Beta feedback</h1>
        <p className="text-sm text-muted-foreground mt-1 mb-6">
          A few minutes of honest feedback helps a lot before launch.
        </p>

        {error && (
          <div className="mb-4 p-3 rounded-2xl bg-pastelPink text-pastelPink-foreground text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="rounded-3xl bg-card border border-border/60 shadow-sm p-5 space-y-4">
            <Field label="Name / GitHub username" hint="Optional">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                className="w-full h-11 px-3.5 rounded-2xl border border-border bg-[hsl(var(--background))] text-sm outline-none focus:border-foreground/40 transition-colors"
              />
            </Field>

            <Field label="Email address" hint="Optional — in case we need to follow up on a bug report">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full h-11 px-3.5 rounded-2xl border border-border bg-[hsl(var(--background))] text-sm outline-none focus:border-foreground/40 transition-colors"
              />
            </Field>

            <Field label="What OS and browser are you using?" hint="Required — e.g. Windows 11 / Chrome" required>
              <input
                type="text"
                value={osBrowser}
                onChange={(e) => setOsBrowser(e.target.value)}
                placeholder="Windows 11 / Chrome"
                className="w-full h-11 px-3.5 rounded-2xl border border-border bg-[hsl(var(--background))] text-sm outline-none focus:border-foreground/40 transition-colors"
              />
            </Field>
          </div>

          <div className="rounded-3xl bg-card border border-border/60 shadow-sm p-5">
            <Field label="How intuitive was the UI/UX?" hint="Required — 1 = very confusing, 5 = extremely intuitive" required>
              <div className="flex gap-2 mt-1">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setRating(n)}
                    className={`flex-1 py-2.5 rounded-2xl text-sm font-semibold border transition-colors ${
                      rating === n
                        ? "bg-pastelPink text-pastelPink-foreground border-pastelPink"
                        : "border-border text-foreground hover:bg-muted"
                    }`}
                  >
                    {n}
                  </button>
                ))}
              </div>
              {rating && (
                <p className="text-xs text-muted-foreground mt-2">{RATING_LABELS[rating]}</p>
              )}
            </Field>
          </div>

          <div className="rounded-3xl bg-card border border-border/60 shadow-sm p-5 space-y-4">
            <Field label="Did you encounter any bugs, crashes, or weird behavior?" hint="Optional — if yes, what were you trying to do when it happened?">
              <textarea
                value={bugs}
                onChange={(e) => setBugs(e.target.value)}
                rows={3}
                placeholder="Describe what happened..."
                className="w-full px-3.5 py-3 rounded-2xl border border-border bg-[hsl(var(--background))] text-sm outline-none focus:border-foreground/40 transition-colors resize-none"
              />
            </Field>

            <Field label="What's one feature you feel is missing before launch?" hint="Optional">
              <textarea
                value={missingFeature}
                onChange={(e) => setMissingFeature(e.target.value)}
                rows={2}
                placeholder="Anything you wish it had..."
                className="w-full px-3.5 py-3 rounded-2xl border border-border bg-[hsl(var(--background))] text-sm outline-none focus:border-foreground/40 transition-colors resize-none"
              />
            </Field>

            <Field label="Any general feedback or first impressions?" hint="Optional">
              <textarea
                value={general}
                onChange={(e) => setGeneral(e.target.value)}
                rows={3}
                placeholder="Anything else on your mind..."
                className="w-full px-3.5 py-3 rounded-2xl border border-border bg-[hsl(var(--background))] text-sm outline-none focus:border-foreground/40 transition-colors resize-none"
              />
            </Field>
          </div>

          <div className="rounded-3xl bg-card border border-border/60 shadow-sm p-5">
            <Field label="Attach a screenshot" hint="Optional — image of a bug or issue, up to 5MB">
              {screenshot ? (
                <div className="flex items-center justify-between gap-2 mt-1 px-3.5 py-2.5 rounded-2xl bg-[hsl(var(--background))] border border-border">
                  <span className="text-sm text-foreground truncate">{screenshot.name}</span>
                  <button
                    type="button"
                    onClick={() => setScreenshot(null)}
                    className="text-muted-foreground hover:text-foreground shrink-0"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="mt-1 flex items-center justify-center gap-2 px-3.5 py-3 rounded-2xl border border-dashed border-border text-sm text-muted-foreground cursor-pointer hover:bg-muted transition-colors">
                  <Paperclip className="w-4 h-4" />
                  Choose image
                  <input type="file" accept="image/*" onChange={handleFile} className="hidden" />
                </label>
              )}
            </Field>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3.5 rounded-2xl bg-primary text-primary-foreground font-semibold text-sm disabled:opacity-50 transition-opacity"
          >
            {submitting ? "Sending..." : "Send feedback"}
          </button>
        </form>
      </div>
    </AppShell>
  );
}

function Field({ label, hint, required, children }) {
  return (
    <div>
      <label className="block text-sm font-semibold text-foreground mb-1">
        {label}
      </label>
      {hint && <p className="text-xs text-muted-foreground mb-2">{hint}</p>}
      {children}
    </div>
  );
}
